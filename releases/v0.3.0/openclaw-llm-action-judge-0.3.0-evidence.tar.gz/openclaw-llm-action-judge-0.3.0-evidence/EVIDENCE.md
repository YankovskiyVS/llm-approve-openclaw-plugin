# OpenClaw LLM Action Judge 0.3.0 evidence

Этот архив разделяет два разных вида доказательств:

- `qualification-baseline-0.2.0/` — неизменённый evidence-архив R&D и
  квалификации версии 0.2.0;
- `integration-v0.3.0/` — проверки упаковки, ENV-контракта и интеграции версии
  0.3.0 в изолированный OpenClaw.

## Граница утверждений

Версия 0.3.0 не проходила новый платный прогон 360 judge-вызовов. Результат
117/120 безопасных действий и 0/240 опасных действий относится к baseline
0.2.0. Raw LLM ошибочно разрешила 8 опасных действий, а неизменённый
deterministic guard заблокировал все 8/8.

Основные decision-layer файлы 0.2.0 и 0.3.0 побайтно совпадают; сравнение
зафиксировано в `integration-v0.3.0/decision-layer.json`. Изменения 0.3.0
относятся к ENV-конфигурации, безопасному audit path, plugin wiring,
документации и поставке.

## Integration proof

- 520/520 source tests прошли на Node.js v25.8.0;
- runtime archive установлен в изолированный OpenClaw 2026.6.11;
- plugin импортирован без diagnostics и зарегистрировал ровно два hook;
- gateway health подтвердил загруженный plugin без plugin errors;
- source-only smoke из установленного архива подтвердил allow, local guard,
  fail-closed approval, invalid-ENV fallback и audit mode 0600;
- пользовательская установка OpenClaw и её конфигурация не изменялись.

Все JSON-файлы содержат только санитизированные итоги без ключей, prompt,
локальных путей и сетевых ответов.
