# openclaw-llm-action-judge 0.5.0 evidence

Дата: 2026-07-17.

Этот архив подтверждает source, package и stock OpenClaw compatibility для
release 0.5.0. Новый unseen model holdout и новый live Cloud.ru judge probe в
этом release cycle не выполнялись; исторические model-selection/holdout цифры
не считаются qualification v0.5.0.

Проверено:

- `npm test`: 906/906 pass;
- release/package suite: 12/12 pass;
- independent Task 4 review: SPEC PASS, QUALITY PASS;
- `git diff --check`: clean;
- frozen/public eval corpora и releases v0.3.0/v0.4.0 не изменены;
- exact `openclaw-llm-action-judge-0.5.0.tgz` установлен archive-install в
  isolated stock OpenClaw 2026.6.11;
- plugin version 0.5.0, status loaded, imported true;
- ровно два typed hook: `before_model_resolve` и `before_tool_call`, оба priority
  -1000; diagnostics пусты;
- isolated gateway health: ok, plugin loaded, plugin errors пусты, event loop не
  degraded;
- installed-tarball smoke: safe allow, deterministic block, supervised
  fail-closed approval, invalid-schema и invalid-ENV fail-closed, audit 0600 и
  secret-free;
- package SHA-256:
  `6d35740ac596b456b4063c5d69cbd68f1a02f31935867b59c3b508ffd5d9581d`.

Реальный `.env` не читался и не менялся. Stock smoke использовал одноразовый
изолированный state и заведомо небоевой synthetic judge key; live provider
request не выполнялся.
