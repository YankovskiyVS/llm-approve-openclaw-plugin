#!/bin/sh
set -eu
npm run eval:harness -- --corpus "$1" --pricing "$2" --output "$3" --repeats 3 --concurrency 4 --openclaw-version 2026.6.11
