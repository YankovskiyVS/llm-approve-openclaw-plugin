# OpenClaw LLM Action Judge 0.4.0 — evidence

Архив содержит два независимых вида доказательств:

- `qualification-policy-2026-07-14.6/` — полный неизменённый результат
  production-profile qualification фиксированной модели
  `Qwen/Qwen3.5-397B-A17B`;
- `integration-v0.4.0/` — санитизированные итоги source tests, проверки
  устанавливаемого `.tgz`, Structured Output, зависимостей и запуска в
  изолированном OpenClaw 2026.6.11.

## Результат qualification

- 120 кейсов, по 3 повтора: 360/360 вызовов завершились без transport,
  timeout или schema failures;
- autonomous: 108/120 безопасных действий выполнены без человека;
- autonomous: 0/240 опасных действий выполнены без человека;
- family-level: 34/40 MUST_ALLOW, 0/80 unsafe MUST_BLOCK;
- catastrophic: 0/11 unsafe families;
- latency p50/p95/p99: 1846.1415 / 2320.6206 / 2761.1264 ms;
- raw judge вернул `allow` для 18 опасных attempts; production normalization
  и local guard понизили все 18/18 до `review`, поэтому в autonomous они были
  заблокированы.

`junit.xml` намеренно содержит `failures="6"`: это шесть MUST_ALLOW families,
в которых хотя бы один из трёх повторов был overblocked. Это не пропущенные
опасные действия. Safety gate релиза — ноль unsafe auto-allow attempts и
families; safe recall публикуется отдельно и не скрывается.

Provider не вернул usage ни в одном из 360 ответов:
`usage.covered_attempts=0`. Поэтому записанный агрегатором `cost=0` означает
«стоимость не наблюдаема по ответам API», а не бесплатный прогон.

Корпус является reviewed regression corpus, на котором policy последовательно
донастраивалась. Это tuned qualification, а не unseen holdout. Перед широким
autonomous rollout нужен shadow/canary на реальном traffic команды.

## Structured Output и граница source

Каждый запрос использовал фиксированный `response_format.type=json_schema` с
`strict=true`. Все 360 ответов прошли локальную Ajv 8.20.0 валидацию точного
семиполевого контракта. Reasoning-текст в verdict не используется.

Qualification manifest привязан к commit
`c05f776c5ee8f647e18c98255a8a02acf19125a2`. Устанавливаемый runtime собран из
`1d921d8b639f8eb67b7d728b451c22a241497084`: между этими точками менялись только
release-документация и release-тест; production decision sources не менялись.

## Integration proof

- 581/581 source tests прошли на Node.js v25.8.0;
- exact runtime `.tgz` содержит 24 allowlisted файла и SHA-256
  `7e2533b8d90431fbfb57e4a72812c5fb067882f161bf89d13342024ea75f9633`;
- clean install с `npm install --omit=peer` установил Ajv 8.20.0 и не установил
  вложенную копию OpenClaw;
- package smoke подтвердил safe allow, deterministic block, supervised
  fail-closed approval, schema-invalid fail-closed, invalid-ENV fail-closed и
  audit JSONL mode 0600 без секретов;
- runtime inspect импортировал plugin, зарегистрировал ровно два typed hook с
  priority -1000 и вернул пустые diagnostics;
- isolated gateway health вернул `ok=true`, plugin loaded, plugin errors пусты,
  event loop не degraded; gateway завершён штатно;
- `hook-only-plugin-shape` — информационное compatibility-сообщение OpenClaw,
  а не ошибка.

## Изоляция хоста

Чистовой smoke задавал одновременно `HOME`, `OPENCLAW_HOME`,
`OPENCLAW_STATE_DIR` и `OPENCLAW_CONFIG_PATH`. На раннем пробном запуске был
задан только `OPENCLAW_STATE_DIR`, из-за чего OpenClaw мигрировал host
`exec-approvals.json`. Файл был сразу восстановлен побайтно; перед и после
чистового smoke подтверждены одинаковые SHA-256, mode, owner и размер.

Все публикуемые JSON и qualification-файлы проверены на API key, private key,
Bearer token и абсолютные home paths. Реальный `.env` не читался и не менялся.
